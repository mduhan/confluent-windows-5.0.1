// +build static
// +build !static_all

package kafka

// #cgo pkg-config: rdkafka-static
import "C"
